import React from 'react'

const ReviewsPage = () => {
  return (
    <div>ReviewsPage</div>
  )
}

export default ReviewsPage