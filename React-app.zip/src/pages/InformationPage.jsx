import React from 'react'

const InformationPage = () => {
  return (
    <div>InformationPage</div>
  )
}

export default InformationPage