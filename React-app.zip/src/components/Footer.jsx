import React from 'react'

const Footer = () => {
  return (
    <footer className='footer'>
        <h2 className='footer-text'>All rights reserved</h2>
    </footer>
  )
}

export default Footer